# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

modules = \
['aoc']
install_requires = \
['requests>=2.28.1,<3.0.0']

setup_kwargs = {
    'name': 'aoc',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Advent of Code Helper\n\nAuto-fetches puzzle inputs from adventofcode.com and passes them to your puzzle\nsolutions ',
    'author': 'David Yue',
    'author_email': 'davidyue5819@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
